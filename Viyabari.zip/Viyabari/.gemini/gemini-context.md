# Fish Trade Management System — Gemini Project Context

## Project Overview

This is a Fish Trade Management System (FTMS) built as a learning project to
understand Java web development with Spring Boot. The system helps fish buyers
purchase fish from boat owners and suppliers, manage stock in cold storage, sell
locally or export internationally, track payments, and generate business reports.

This is a monolithic Spring Boot web application using Thymeleaf for server-side
HTML rendering. There is NO separate frontend framework. All pages are rendered
by the Spring Boot server and returned as HTML.

---

## Developer Profile

- Learning Java web development
- IDE: IntelliJ IDEA on Linux Mint (Ubuntu 22.04 base)
- Experience level: beginner to intermediate
- Prefers clear, simple, well-commented code
- Wants to understand why, not just what
- Follows a step-by-step learning approach

---

## Tech Stack

| Layer       | Technology                      | Version        |
|-------------|---------------------------------|----------------|
| Language    | Java                            | 17             |
| Framework   | Spring Boot                     | 3.2.x          |
| ORM         | Spring Data JPA + Hibernate     | bundled        |
| Database    | MySQL                           | 8.0            |
| Template    | Thymeleaf                       | bundled        |
| Build tool  | Maven                           | 3.6.3          |
| Helpers     | Lombok                          | latest stable  |
| Mapper      | MapStruct                       | 1.5.5.Final    |
| Migration   | Flyway                          | bundled        |
| Security    | Spring Security                 | added Phase 7  |
| OS          | Linux Mint (Ubuntu 22.04 base)  | —              |

---

## Maven Dependencies (pom.xml)

- spring-boot-starter-web
- spring-boot-starter-data-jpa
- spring-boot-starter-thymeleaf
- spring-boot-starter-validation
- mysql-connector-j
- lombok
- mapstruct 1.5.5.Final
- flyway-core
- spring-boot-starter-security  (added in Phase 7 only)

Always use Jakarta imports (jakarta.persistence, jakarta.validation).
NEVER use javax imports — Spring Boot 3 requires Jakarta namespace exclusively.

---

## application.properties

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/fishtrade_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=Root@123
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# Schema managed exclusively by Flyway. NEVER change to create or update.
spring.jpa.hibernate.ddl-auto=validate
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect

spring.thymeleaf.cache=false

spring.flyway.enabled=true
spring.flyway.locations=classpath:db/migration
```

---

## Package Structure (Feature-Based)

This project uses package-by-feature. NOT package-by-layer.
Each feature package contains its own controller, service, repository, entity, DTOs, and mapper.
NEVER create root-level controller/, service/, or repository/ packages.

```
com.fishtrade/
├── supplier/       # Supplier & Boat — entities, repo, service, controller, DTOs, mapper
├── fish/           # Fish & FishCategory feature
├── purchase/       # PurchaseMaster & PurchaseItem feature
├── quality/        # QualityInspection feature
├── inventory/      # Stock management feature
├── coldstorage/    # ColdStorage & StorageTransaction feature
├── customer/       # Customer management feature
├── sales/          # SalesMaster & SalesItem feature
├── export/         # ExportOrder & ExportOrderItem feature
├── payment/        # Financial transactions feature
├── expense/        # Operational expenses feature
├── transport/      # Vehicle & Delivery feature
├── report/         # Business reports and analytics
└── shared/
    ├── exception/  # ResourceNotFoundException, BusinessException, GlobalExceptionHandler
    ├── config/     # WebConfig, SecurityConfig (added Phase 7)
    └── audit/      # AuditLog
```

### Class naming per feature (example using supplier)

| Role            | Class name               |
|-----------------|--------------------------|
| Entity          | Supplier                 |
| Repository      | SupplierRepository       |
| Service         | SupplierService          |
| Controller      | SupplierController       |
| Input DTO       | SupplierRequestDTO       |
| Output DTO      | SupplierResponseDTO      |
| Mapper          | SupplierMapper           |

---

## Layered Architecture Rules

Call direction is strictly: Controller → Service → Repository.
Never skip a layer. Never call upward.

### Controller layer rules
- Annotated with @Controller — NEVER @RestController (this is a Thymeleaf project)
- Handles HTTP GET and POST requests only
- Calls Service methods only — NEVER calls Repository directly
- Adds data to Model for Thymeleaf templates
- Contains ZERO business logic or calculations
- Contains ZERO SQL or JPA queries
- Returns a String (template path) or redirect

### Service layer rules
- Annotated with @Service
- Contains ALL business logic, rules, and calculations
- All write operations annotated with @Transactional
- All read operations annotated with @Transactional(readOnly = true)
- Calls Repository methods only
- May call another feature's Service when needed
- NEVER calls a Controller
- NEVER calls a Repository from another feature directly

### Repository layer rules
- Extends JpaRepository<Entity, IdType>
- Annotated with @Repository
- Contains ONLY data access — zero business logic
- Custom queries use @Query with JPQL
- Use native SQL only when JPQL cannot express the query

### Entity layer rules
- Annotated with @Entity and @Table(name = "table_name")
- All relationships use FetchType.LAZY — NEVER FetchType.EAGER
- @OneToMany uses cascade = CascadeType.ALL and orphanRemoval = true
- Use @Enumerated(EnumType.STRING) — NEVER EnumType.ORDINAL
- Use @CreationTimestamp and @UpdateTimestamp for audit fields
- NEVER expose entities directly to a Controller or Thymeleaf template
- Always convert entity to DTO before passing to the Controller

### DTO rules
- Separate DTO for input (RequestDTO) and output (ResponseDTO)
- Plain Java classes — no JPA annotations on DTOs
- Use Lombok @Getter @Setter @NoArgsConstructor on all DTOs
- Use MapStruct mapper interface to convert between entity and DTO

---

## Naming Conventions

### Java naming
- Classes: PascalCase — Supplier, PurchaseMaster, FishCategory
- Methods: camelCase — getAll(), getById(), save(), update(), delete()
- Variables: camelCase — supplierId, purchaseDate, totalAmount
- Boolean fields: is prefix — isActive, isPaid
- List variables: plural noun — suppliers, purchaseItems

### Standard service method names
- getAll()            — fetch all records
- getById(id)         — fetch one record by primary key
- save(requestDTO)    — create a new record
- update(id, requestDTO) — update existing record
- delete(id)          — delete record
- findBy___()         — custom search methods

### Database naming (snake_case always)
- Primary keys: tablename_id — supplier_id, boat_id, fish_id, purchase_id
- Foreign keys: same as referenced primary key — supplier_id, fish_id
- Boolean columns: is_ prefix — is_active, is_paid
- Timestamp columns: created_at, updated_at
- Amount columns: _amount suffix — total_amount, paid_amount
- Quantity columns: _qty suffix — current_qty, reserved_qty

### Thymeleaf URL mapping (kebab-case)
- List page:   GET  /supplier/list
- Add form:    GET  /supplier/add
- Save new:    POST /supplier/save
- Edit form:   GET  /supplier/edit/{id}
- Update:      POST /supplier/update/{id}
- Delete:      POST /supplier/delete/{id}

### Thymeleaf template paths
- src/main/resources/templates/supplier/list.html
- src/main/resources/templates/supplier/add.html
- src/main/resources/templates/supplier/edit.html

---

## Database Tables

Schema lives in: src/main/resources/db/migration/

### Master / Reference tables
- users, roles, user_roles
- suppliers, boats
- fish_categories, fishes
- customers, vehicles

### Transactional tables
- purchase_master, purchase_items
- quality_inspections
- inventory
- cold_storage_rooms, storage_transactions
- sales_master, sales_items
- export_orders, export_order_items
- payments
- expenses
- deliveries

### Key relationships
- boats.owner_id → suppliers.supplier_id
- purchase_master.supplier_id → suppliers.supplier_id
- purchase_master.boat_id → boats.boat_id
- purchase_items.purchase_id → purchase_master.purchase_id
- purchase_items.fish_id → fishes.fish_id
- fishes.category_id → fish_categories.category_id
- inventory.fish_id → fishes.fish_id
- sales_master.customer_id → customers.customer_id
- sales_items.sale_id → sales_master.sale_id
- sales_items.fish_id → fishes.fish_id
- payments.supplier_id → suppliers.supplier_id (nullable)
- payments.customer_id → customers.customer_id (nullable)

### Flyway migration file naming
V{number}__{description}.sql — two underscores between version and description.
NEVER modify an existing migration file after it has been applied.
New changes always go in a new migration file with the next version number.

```
V1__create_users_roles.sql
V2__create_suppliers_boats.sql
V3__create_fish_catalog.sql
V4__create_purchase_tables.sql
V5__create_quality_inspection.sql
V6__create_inventory.sql
V7__create_cold_storage.sql
V8__create_customers.sql
V9__create_sales_tables.sql
V10__create_export_tables.sql
V11__create_payments.sql
V12__create_expenses.sql
V13__create_transport.sql
V14__create_audit_log.sql
```

---

## Enum Types

```java
enum SupplierType    { BOAT_OWNER, AUCTION, TRADER }
enum FishGrade       { A, B, C }
enum PurchaseStatus  { DRAFT, CONFIRMED, CANCELLED }
enum PaymentStatus   { PENDING, PARTIAL, PAID }
enum PaymentType     { TO_SUPPLIER, FROM_CUSTOMER }
enum SaleType        { LOCAL, EXPORT }
enum ExpenseCategory { FUEL, ICE, TRANSPORTATION, PACKAGING, LABOR, COLD_STORAGE }
```

Use @Enumerated(EnumType.STRING) on every enum field in every entity.

---

## Business Rules

1.  purchase_items.total_amount is always quantity_kg × rate_per_kg — never store manually
2.  inventory available_qty = current_qty − reserved_qty − damaged_qty
3.  When a purchase status changes to CONFIRMED, inventory must increase automatically
4.  When a sale is saved, inventory current_qty must decrease by quantity sold
5.  Purchases must be blocked if the supplier is_active = false
6.  PaymentStatus is derived: PAID if paid_amount = total_amount, PARTIAL if paid_amount > 0, PENDING if paid_amount = 0
7.  Export orders require shipment_date, container_number, and destination_country
8.  Cold storage rooms warn when current_load exceeds 90% of capacity
9.  Purchase number format: PUR-YYYY-NNNN   (example: PUR-2025-0001)
10. Sales invoice number format: INV-YYYY-NNNN
11. Export order number format: EXP-YYYY-NNNN

---

## Thymeleaf Template Structure

```
src/main/resources/
├── templates/
│   ├── layout/
│   │   └── main.html          # common layout — header, sidebar, footer
│   ├── supplier/
│   │   ├── list.html
│   │   ├── add.html
│   │   └── edit.html
│   ├── boat/
│   ├── fish/
│   ├── purchase/
│   ├── quality/
│   ├── inventory/
│   ├── coldstorage/
│   ├── customer/
│   ├── sales/
│   ├── export/
│   ├── payment/
│   ├── expense/
│   ├── transport/
│   ├── report/
│   └── error/
│       └── error.html
└── static/
    ├── css/
    │   └── style.css
    └── js/
        └── main.js
```

---

## What Gemini Must Always Do

- Use Jakarta imports exclusively — never javax
- Add @Transactional on every service write method
- Add @Transactional(readOnly = true) on every service read method
- Use FetchType.LAZY on all entity relationships
- Use @Enumerated(EnumType.STRING) on all enum fields
- Validate all form input using @Valid and constraint annotations
- Convert entity to DTO before returning from service to controller
- Add comments explaining WHY the code works, not just what it does
- Place every class inside its correct feature package
- Use Lombok to reduce boilerplate on entities and DTOs
- Show Thymeleaf field errors on forms using th:errors
- Follow the standard service method naming: getAll, getById, save, update, delete

---

## What Gemini Must Never Do

- NEVER use javax.* — always jakarta.*
- NEVER use @RestController — always @Controller for Thymeleaf pages
- NEVER call a repository directly from a controller
- NEVER put business logic inside a controller
- NEVER expose a JPA entity directly in a Thymeleaf template — always use DTO
- NEVER use FetchType.EAGER on any relationship
- NEVER use EnumType.ORDINAL — always EnumType.STRING
- NEVER change spring.jpa.hibernate.ddl-auto to create, update, or create-drop
- NEVER modify an existing Flyway migration file
- NEVER use native SQL unless JPQL cannot express the query
- NEVER create classes in a root-level controller/, service/, or repository/ package
- NEVER add Spring Security code before Phase 7

---

## Current Development Phase

Phase 1 — Foundation (current)
- [x] Spring Boot project created with correct dependencies
- [x] MySQL database connected and verified
- [x] GEMINI.md context file created
- [ ] Step 1: Package structure — create all feature packages
- [ ] Step 2: Flyway migrations — create all database tables
- [ ] Step 3: Entity classes — map all tables to Java classes
- [ ] Step 4: Repository interfaces
- [ ] Step 5: Lombok and MapStruct configured

Phase 2 — Supplier feature (not started)
Phase 3 — Core features (not started)
Phase 4 — Sales (not started)
Phase 5 — Finance (not started)
Phase 6 — Logistics (not started)
Phase 7 — Security (not started)
Phase 8 — Reports (not started)
Phase 9 — Polish (not started)