package com.fishtrade.transport;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
public class DeliveryRequestDTO {
    @NotNull(message = "Sale selection is required")
    private Long saleId;
    
    @NotNull(message = "Vehicle selection is required")
    private Long vehicleId;
    
    private String driverName;
    private LocalDateTime deliveryDate = LocalDateTime.now();
    private String status = "IN_TRANSIT";
}
