package com.fishtrade.transport;

import com.fishtrade.sales.SalesService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/logistics/transport")
@RequiredArgsConstructor
public class TransportController {

    private final TransportService transportService;
    private final SalesService salesService;

    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("vehicles", transportService.getAllVehicles());
        model.addAttribute("deliveries", transportService.getAllDeliveries());
        return "logistics/transport-list";
    }

    @GetMapping("/vehicle/add")
    public String showVehicleForm(Model model) {
        model.addAttribute("vehicleRequestDTO", new VehicleRequestDTO());
        return "logistics/vehicle-add";
    }

    @PostMapping("/vehicle/save")
    public String saveVehicle(@Valid @ModelAttribute VehicleRequestDTO dto, 
                             BindingResult bindingResult, 
                             RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) return "logistics/vehicle-add";
        transportService.saveVehicle(dto);
        redirectAttributes.addFlashAttribute("successMessage", "Vehicle registered successfully");
        return "redirect:/logistics/transport/list";
    }

    @GetMapping("/delivery/add")
    public String showDeliveryForm(Model model) {
        model.addAttribute("deliveryRequestDTO", new DeliveryRequestDTO());
        model.addAttribute("sales", salesService.getAll());
        model.addAttribute("vehicles", transportService.getAllVehicles());
        return "logistics/delivery-add";
    }

    @PostMapping("/delivery/save")
    public String saveDelivery(@Valid @ModelAttribute DeliveryRequestDTO dto, 
                              BindingResult bindingResult, 
                              Model model,
                              RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("sales", salesService.getAll());
            model.addAttribute("vehicles", transportService.getAllVehicles());
            return "logistics/delivery-add";
        }
        transportService.scheduleDelivery(dto);
        redirectAttributes.addFlashAttribute("successMessage", "Delivery scheduled successfully");
        return "redirect:/logistics/transport/list";
    }
}
