package com.fishtrade.transport;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class VehicleRequestDTO {
    @NotBlank(message = "Vehicle number is required")
    private String vehicleNumber;
    private String vehicleType;
    private String ownerName;
}
