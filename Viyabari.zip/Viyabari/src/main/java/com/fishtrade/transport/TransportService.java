package com.fishtrade.transport;

import com.fishtrade.sales.SalesMaster;
import com.fishtrade.sales.SalesMasterRepository;
import com.fishtrade.shared.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TransportService {

    private final VehicleRepository vehicleRepository;
    private final DeliveryRepository deliveryRepository;
    private final SalesMasterRepository salesMasterRepository;
    private final TransportMapper mapper;

    @Transactional(readOnly = true)
    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }

    @Transactional
    public void saveVehicle(VehicleRequestDTO dto) {
        vehicleRepository.save(mapper.toVehicleEntity(dto));
    }

    @Transactional(readOnly = true)
    public List<Delivery> getAllDeliveries() {
        return deliveryRepository.findAll();
    }

    @Transactional
    public void scheduleDelivery(DeliveryRequestDTO dto) {
        SalesMaster sale = salesMasterRepository.findById(dto.getSaleId())
                .orElseThrow(() -> new ResourceNotFoundException("Sale not found"));
        
        Vehicle vehicle = vehicleRepository.findById(dto.getVehicleId())
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found"));

        Delivery delivery = mapper.toDeliveryEntity(dto);
        delivery.setSale(sale);
        delivery.setVehicle(vehicle);

        deliveryRepository.save(delivery);
    }
}
