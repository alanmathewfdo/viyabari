package com.fishtrade.transport;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface TransportMapper {

    Vehicle toVehicleEntity(VehicleRequestDTO dto);
    List<Vehicle> toVehicleList(List<Vehicle> vehicles);

    @Mapping(target = "sale", ignore = true)
    @Mapping(target = "vehicle", ignore = true)
    Delivery toDeliveryEntity(DeliveryRequestDTO dto);
}
