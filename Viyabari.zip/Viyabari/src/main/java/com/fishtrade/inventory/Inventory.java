package com.fishtrade.inventory;

import com.fishtrade.fish.Fish;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "inventory")
@Getter
@Setter
@NoArgsConstructor
public class Inventory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long inventoryId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fish_id", nullable = false, unique = true)
    private Fish fish;

    private BigDecimal currentQty = BigDecimal.ZERO;
    private BigDecimal reservedQty = BigDecimal.ZERO;
    private BigDecimal damagedQty = BigDecimal.ZERO;

    @UpdateTimestamp
    private LocalDateTime lastUpdated;
}
