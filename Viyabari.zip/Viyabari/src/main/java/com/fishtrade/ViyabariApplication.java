package com.fishtrade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViyabariApplication {

    public static void main(String[] args) {
        SpringApplication.run(ViyabariApplication.class, args);
    }

}
