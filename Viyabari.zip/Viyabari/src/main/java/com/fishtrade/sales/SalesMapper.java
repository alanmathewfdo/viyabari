package com.fishtrade.sales;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface SalesMapper {

    @Mapping(source = "customer.customerId", target = "customerId")
    @Mapping(source = "customer.name", target = "customerName")
    SalesResponseDTO toResponseDTO(SalesMaster sale);

    @Mapping(source = "fish.fishId", target = "fishId")
    @Mapping(source = "fish.name", target = "fishName")
    SalesItemResponseDTO toItemResponseDTO(SalesItem item);

    @Mapping(target = "customer", ignore = true)
    @Mapping(target = "items", ignore = true)
    SalesMaster toEntity(SalesRequestDTO dto);

    @Mapping(target = "fish", ignore = true)
    @Mapping(target = "sale", ignore = true)
    SalesItem toItemEntity(SalesItemRequestDTO dto);

    List<SalesResponseDTO> toResponseDTOList(List<SalesMaster> sales);
}
