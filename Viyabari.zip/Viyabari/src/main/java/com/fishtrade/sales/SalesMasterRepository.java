package com.fishtrade.sales;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SalesMasterRepository extends JpaRepository<SalesMaster, Long> {
}
