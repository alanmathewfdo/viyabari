package com.fishtrade.sales;

public enum SaleType {
    LOCAL, EXPORT
}
