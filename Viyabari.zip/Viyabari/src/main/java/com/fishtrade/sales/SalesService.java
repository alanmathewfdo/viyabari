package com.fishtrade.sales;

import com.fishtrade.customer.Customer;
import com.fishtrade.customer.CustomerRepository;
import com.fishtrade.fish.Fish;
import com.fishtrade.fish.FishRepository;
import com.fishtrade.shared.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SalesService {

    private final SalesMasterRepository salesMasterRepository;
    private final CustomerRepository customerRepository;
    private final FishRepository fishRepository;
    private final SalesMapper salesMapper;

    @Transactional(readOnly = true)
    public List<SalesResponseDTO> getAll() {
        return salesMapper.toResponseDTOList(salesMasterRepository.findAll());
    }

    @Transactional
    public SalesResponseDTO save(SalesRequestDTO dto) {
        Customer customer = customerRepository.findById(dto.getCustomerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found"));

        SalesMaster sale = salesMapper.toEntity(dto);
        sale.setCustomer(customer);
        sale.setInvoiceNumber(generateInvoiceNumber());

        BigDecimal grandTotal = BigDecimal.ZERO;

        for (SalesItemRequestDTO itemDto : dto.getItems()) {
            Fish fish = fishRepository.findById(itemDto.getFishId())
                    .orElseThrow(() -> new ResourceNotFoundException("Fish not found: " + itemDto.getFishId()));

            SalesItem item = salesMapper.toItemEntity(itemDto);
            item.setFish(fish);
            item.setSale(sale);
            
            BigDecimal lineTotal = itemDto.getQuantityKg().multiply(itemDto.getRatePerKg());
            item.setTotalAmount(lineTotal);
            grandTotal = grandTotal.add(lineTotal);
            
            sale.getItems().add(item);
        }

        sale.setTotalAmount(grandTotal);
        return salesMapper.toResponseDTO(salesMasterRepository.save(sale));
    }

    private String generateInvoiceNumber() {
        long count = salesMasterRepository.count() + 1;
        return String.format("INV-%d-%04d", LocalDate.now().getYear(), count);
    }

    @Transactional(readOnly = true)
    public SalesResponseDTO getById(Long id) {
        SalesMaster sale = salesMasterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Sale not found"));
        return salesMapper.toResponseDTO(sale);
    }
}
