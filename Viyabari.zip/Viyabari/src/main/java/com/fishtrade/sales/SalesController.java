package com.fishtrade.sales;

import com.fishtrade.customer.CustomerRepository;
import com.fishtrade.fish.FishService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/sales")
@RequiredArgsConstructor
public class SalesController {

    private final SalesService salesService;
    private final CustomerRepository customerRepository;
    private final FishService fishService;

    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("sales", salesService.getAll());
        return "sales/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        SalesRequestDTO dto = new SalesRequestDTO();
        // Add one empty item by default
        dto.getItems().add(new SalesItemRequestDTO());
        
        model.addAttribute("salesRequestDTO", dto);
        model.addAttribute("customers", customerRepository.findAll());
        model.addAttribute("fishes", fishService.getAllFishes());
        model.addAttribute("saleTypes", SaleType.values());
        model.addAttribute("statuses", SalesStatus.values());
        return "sales/add";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute SalesRequestDTO dto, 
                       BindingResult bindingResult, 
                       Model model,
                       RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("customers", customerRepository.findAll());
            model.addAttribute("fishes", fishService.getAllFishes());
            model.addAttribute("saleTypes", SaleType.values());
            model.addAttribute("statuses", SalesStatus.values());
            return "sales/add";
        }
        salesService.save(dto);
        redirectAttributes.addFlashAttribute("successMessage", "Sale invoice created successfully");
        return "redirect:/sales/list";
    }

    @GetMapping("/view/{id}")
    public String view(@PathVariable Long id, Model model) {
        model.addAttribute("sale", salesService.getById(id));
        return "sales/view";
    }
}
