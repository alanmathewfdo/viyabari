package com.fishtrade.sales;

import com.fishtrade.fish.Fish;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "sales_items")
@Getter
@Setter
@NoArgsConstructor
public class SalesItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long saleItemId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sale_id", nullable = false)
    private SalesMaster sale;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fish_id", nullable = false)
    private Fish fish;

    @Column(nullable = false)
    private BigDecimal quantityKg;

    @Column(nullable = false)
    private BigDecimal ratePerKg;

    @Column(nullable = false)
    private BigDecimal totalAmount;
}
