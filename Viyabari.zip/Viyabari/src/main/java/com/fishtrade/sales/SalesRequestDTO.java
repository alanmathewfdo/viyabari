package com.fishtrade.sales;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class SalesRequestDTO {

    @NotNull(message = "Customer is required")
    private Long customerId;

    @NotNull(message = "Sale date is required")
    private LocalDate saleDate = LocalDate.now();

    @NotNull(message = "Sale type is required")
    private SaleType saleType = SaleType.LOCAL;

    @NotNull(message = "Status is required")
    private SalesStatus status = SalesStatus.DRAFT;

    private String notes;

    @NotEmpty(message = "At least one item must be added to the sale")
    @Valid
    private List<SalesItemRequestDTO> items = new ArrayList<>();
}
