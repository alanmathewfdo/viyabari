package com.fishtrade.sales;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
public class SalesItemResponseDTO {
    private Long saleItemId;
    private Long fishId;
    private String fishName;
    private BigDecimal quantityKg;
    private BigDecimal ratePerKg;
    private BigDecimal totalAmount;
}
