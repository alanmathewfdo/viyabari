package com.fishtrade.sales;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class SalesResponseDTO {
    private Long saleId;
    private String invoiceNumber;
    private Long customerId;
    private String customerName;
    private LocalDate saleDate;
    private SaleType saleType;
    private BigDecimal totalAmount;
    private SalesStatus status;
    private String notes;
    private List<SalesItemResponseDTO> items;
}
