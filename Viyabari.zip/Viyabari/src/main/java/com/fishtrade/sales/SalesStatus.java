package com.fishtrade.sales;

public enum SalesStatus {
    DRAFT, COMPLETED, CANCELLED
}
