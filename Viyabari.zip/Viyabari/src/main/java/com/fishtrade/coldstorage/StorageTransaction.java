package com.fishtrade.coldstorage;

import com.fishtrade.fish.Fish;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "storage_transactions")
@Getter
@Setter
@NoArgsConstructor
public class StorageTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id", nullable = false)
    private ColdStorageRoom room;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fish_id", nullable = false)
    private Fish fish;

    @Column(nullable = false)
    private String transactionType; // IN, OUT

    @Column(nullable = false)
    private BigDecimal quantityKg;

    @CreationTimestamp
    private LocalDateTime transactionDate;
}
