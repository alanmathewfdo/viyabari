package com.fishtrade.coldstorage;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
public class StorageTransactionRequestDTO {

    @NotNull(message = "Storage room is required")
    private Long roomId;

    @NotNull(message = "Fish selection is required")
    private Long fishId;

    @NotBlank(message = "Transaction type (IN/OUT) is required")
    private String transactionType;

    @NotNull(message = "Quantity is required")
    @DecimalMin(value = "0.01", message = "Quantity must be greater than zero")
    private BigDecimal quantityKg;
}
