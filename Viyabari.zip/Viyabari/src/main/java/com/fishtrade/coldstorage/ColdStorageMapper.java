package com.fishtrade.coldstorage;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ColdStorageMapper {

    ColdStorageRoomResponseDTO toRoomResponseDTO(ColdStorageRoom room);
    List<ColdStorageRoomResponseDTO> toRoomResponseList(List<ColdStorageRoom> rooms);

    @Mapping(source = "room.roomName", target = "roomName")
    @Mapping(source = "fish.name", target = "fishName")
    StorageTransactionResponseDTO toTransactionResponseDTO(StorageTransaction transaction);
    List<StorageTransactionResponseDTO> toTransactionResponseList(List<StorageTransaction> transactions);

    @Mapping(target = "room", ignore = true)
    @Mapping(target = "fish", ignore = true)
    StorageTransaction toEntity(StorageTransactionRequestDTO dto);
}
