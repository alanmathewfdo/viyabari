package com.fishtrade.coldstorage;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
public class StorageTransactionResponseDTO {
    private Long transactionId;
    private String roomName;
    private String fishName;
    private String transactionType;
    private BigDecimal quantityKg;
    private LocalDateTime transactionDate;
}
