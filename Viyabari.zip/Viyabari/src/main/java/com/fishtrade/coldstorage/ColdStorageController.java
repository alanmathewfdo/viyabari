package com.fishtrade.coldstorage;

import com.fishtrade.fish.FishService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/logistics/cold-storage")
@RequiredArgsConstructor
public class ColdStorageController {

    private final ColdStorageService coldStorageService;
    private final FishService fishService;

    @GetMapping("/status")
    public String status(Model model) {
        model.addAttribute("rooms", coldStorageService.getAllRooms());
        model.addAttribute("transactions", coldStorageService.getRecentTransactions());
        return "logistics/cold-storage-status";
    }

    @GetMapping("/transaction")
    public String showTransactionForm(Model model) {
        model.addAttribute("storageTransactionRequestDTO", new StorageTransactionRequestDTO());
        model.addAttribute("rooms", coldStorageService.getAllRooms());
        model.addAttribute("fishes", fishService.getAllFishes());
        return "logistics/storage-transaction";
    }

    @PostMapping("/transaction/save")
    public String saveTransaction(@Valid @ModelAttribute StorageTransactionRequestDTO dto, 
                                  BindingResult bindingResult, 
                                  Model model,
                                  RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("rooms", coldStorageService.getAllRooms());
            model.addAttribute("fishes", fishService.getAllFishes());
            return "logistics/storage-transaction";
        }
        coldStorageService.recordTransaction(dto);
        redirectAttributes.addFlashAttribute("successMessage", "Storage movement recorded successfully");
        return "redirect:/logistics/cold-storage/status";
    }
}
