package com.fishtrade.coldstorage;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "cold_storage_rooms")
@Getter
@Setter
@NoArgsConstructor
public class ColdStorageRoom {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long roomId;

    @Column(nullable = false, unique = true)
    private String roomName;

    @Column(nullable = false)
    private BigDecimal capacityKg;

    private BigDecimal currentLoad = BigDecimal.ZERO;
    private BigDecimal temperatureCelsius;
    private boolean isActive = true;
}
