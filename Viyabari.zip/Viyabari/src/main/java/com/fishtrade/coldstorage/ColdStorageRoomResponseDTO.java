package com.fishtrade.coldstorage;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
public class ColdStorageRoomResponseDTO {
    private Long roomId;
    private String roomName;
    private BigDecimal capacityKg;
    private BigDecimal currentLoad;
    private BigDecimal temperatureCelsius;
    private boolean isActive;
}
