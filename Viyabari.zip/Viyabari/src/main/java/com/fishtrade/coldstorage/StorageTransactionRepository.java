package com.fishtrade.coldstorage;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StorageTransactionRepository extends JpaRepository<StorageTransaction, Long> {
}
