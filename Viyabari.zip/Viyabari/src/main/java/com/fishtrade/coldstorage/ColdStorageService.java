package com.fishtrade.coldstorage;

import com.fishtrade.fish.Fish;
import com.fishtrade.fish.FishRepository;
import com.fishtrade.shared.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ColdStorageService {

    private final ColdStorageRepository coldStorageRepository;
    private final StorageTransactionRepository transactionRepository;
    private final FishRepository fishRepository;
    private final ColdStorageMapper mapper;

    @Transactional(readOnly = true)
    public List<ColdStorageRoomResponseDTO> getAllRooms() {
        return mapper.toRoomResponseList(coldStorageRepository.findAll());
    }

    @Transactional
    public void recordTransaction(StorageTransactionRequestDTO dto) {
        ColdStorageRoom room = coldStorageRepository.findById(dto.getRoomId())
                .orElseThrow(() -> new ResourceNotFoundException("Storage room not found"));
        
        Fish fish = fishRepository.findById(dto.getFishId())
                .orElseThrow(() -> new ResourceNotFoundException("Fish not found"));

        StorageTransaction transaction = mapper.toEntity(dto);
        transaction.setRoom(room);
        transaction.setFish(fish);

        // Update current load in the room
        if ("IN".equalsIgnoreCase(dto.getTransactionType())) {
            room.setCurrentLoad(room.getCurrentLoad().add(dto.getQuantityKg()));
        } else {
            room.setCurrentLoad(room.getCurrentLoad().subtract(dto.getQuantityKg()));
        }

        transactionRepository.save(transaction);
        coldStorageRepository.save(room);
    }

    @Transactional(readOnly = true)
    public List<StorageTransactionResponseDTO> getRecentTransactions() {
        return mapper.toTransactionResponseList(transactionRepository.findAll());
    }
}
