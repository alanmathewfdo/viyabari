package com.fishtrade.purchase;

import com.fishtrade.fish.Fish;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "purchase_items")
@Getter
@Setter
@NoArgsConstructor
public class PurchaseItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long purchaseItemId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "purchase_id", nullable = false)
    private PurchaseMaster purchase;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fish_id", nullable = false)
    private Fish fish;

    @Column(nullable = false)
    private BigDecimal quantityKg;

    @Column(nullable = false)
    private BigDecimal ratePerKg;

    @Column(nullable = false)
    private BigDecimal totalAmount;

    private String grade; // FishGrade as String or Enum
}
