package com.fishtrade.purchase;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PurchaseMasterRepository extends JpaRepository<PurchaseMaster, Long> {
}
