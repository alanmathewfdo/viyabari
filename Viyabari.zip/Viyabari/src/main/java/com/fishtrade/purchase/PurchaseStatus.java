package com.fishtrade.purchase;

public enum PurchaseStatus {
    DRAFT, CONFIRMED, CANCELLED
}
