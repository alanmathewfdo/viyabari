package com.fishtrade.export;

import com.fishtrade.sales.SalesMaster;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "export_orders")
@Getter
@Setter
@NoArgsConstructor
public class ExportOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long exportId;

    @Column(nullable = false, unique = true)
    private String exportOrderNumber;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sale_id", nullable = false)
    private SalesMaster sale;

    private LocalDate shipmentDate;
    private String containerNumber;
    private String destinationCountry;
    private String portOfLoading;
    private String portOfDischarge;
    private String status; // PENDING, SHIPPED, DELIVERED
}
