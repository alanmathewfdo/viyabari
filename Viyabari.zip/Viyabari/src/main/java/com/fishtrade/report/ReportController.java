package com.fishtrade.report;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/dashboard")
    public String reportsDashboard(Model model) {
        model.addAttribute("salesSummary", reportService.getSalesSummary());
        model.addAttribute("purchaseSummary", reportService.getPurchaseSummary());
        model.addAttribute("stockReport", reportService.getStockReport());
        model.addAttribute("profitLoss", reportService.getProfitLossSummary());
        return "report/dashboard";
    }
}
