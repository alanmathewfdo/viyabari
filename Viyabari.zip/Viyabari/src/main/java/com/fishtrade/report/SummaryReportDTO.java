package com.fishtrade.report;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SummaryReportDTO {
    private String label;
    private Long count;
    private BigDecimal totalAmount;
}
