package com.fishtrade.report;

import com.fishtrade.expense.ExpenseRepository;
import com.fishtrade.inventory.InventoryRepository;
import com.fishtrade.purchase.PurchaseMasterRepository;
import com.fishtrade.sales.SalesMasterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final SalesMasterRepository salesMasterRepository;
    private final PurchaseMasterRepository purchaseMasterRepository;
    private final ExpenseRepository expenseRepository;
    private final InventoryRepository inventoryRepository;

    @Transactional(readOnly = true)
    public List<SummaryReportDTO> getSalesSummary() {
        // Mocking grouping logic for now, in real app use @Query with GROUP BY
        BigDecimal total = salesMasterRepository.findAll().stream()
                .map(s -> s.getTotalAmount())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        return List.of(new SummaryReportDTO("All Sales", salesMasterRepository.count(), total));
    }

    @Transactional(readOnly = true)
    public List<SummaryReportDTO> getPurchaseSummary() {
        BigDecimal total = purchaseMasterRepository.findAll().stream()
                .map(p -> p.getTotalAmount())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        return List.of(new SummaryReportDTO("All Purchases", purchaseMasterRepository.count(), total));
    }

    @Transactional(readOnly = true)
    public List<StockReportDTO> getStockReport() {
        return inventoryRepository.findAll().stream()
                .map(i -> new StockReportDTO(i.getFish().getName(), i.getFish().getCategory().getName(), i.getCurrentQty()))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ProfitLossReportDTO getProfitLossSummary() {
        BigDecimal sales = salesMasterRepository.findAll().stream()
                .map(s -> s.getTotalAmount()).reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal purchases = purchaseMasterRepository.findAll().stream()
                .map(p -> p.getTotalAmount()).reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal expenses = expenseRepository.findAll().stream()
                .map(e -> e.getAmount()).reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal gross = sales.subtract(purchases);
        BigDecimal net = gross.subtract(expenses);

        return ProfitLossReportDTO.builder()
                .totalSales(sales)
                .totalPurchases(purchases)
                .totalExpenses(expenses)
                .grossProfit(gross)
                .netProfit(net)
                .build();
    }
}
