package com.fishtrade.report;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StockReportDTO {
    private String fishName;
    private String categoryName;
    private BigDecimal currentQty;
}
