package com.fishtrade.supplier;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/supplier")
@RequiredArgsConstructor
public class SupplierController {

    private final SupplierService supplierService;

    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("suppliers", supplierService.getAll());
        return "supplier/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("supplierRequestDTO", new SupplierRequestDTO());
        model.addAttribute("types", SupplierType.values());
        return "supplier/add";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute SupplierRequestDTO requestDTO, 
                       BindingResult bindingResult, 
                       Model model,
                       RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("types", SupplierType.values());
            return "supplier/add";
        }
        supplierService.save(requestDTO);
        redirectAttributes.addFlashAttribute("successMessage", "Supplier added successfully");
        return "redirect:/supplier/list";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        model.addAttribute("supplierRequestDTO", supplierService.getById(id));
        model.addAttribute("supplierId", id);
        model.addAttribute("types", SupplierType.values());
        return "supplier/edit";
    }

    @PostMapping("/update/{id}")
    public String update(@PathVariable Long id, 
                         @Valid @ModelAttribute SupplierRequestDTO requestDTO, 
                         BindingResult bindingResult, 
                         Model model,
                         RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("supplierId", id);
            model.addAttribute("types", SupplierType.values());
            return "supplier/edit";
        }
        supplierService.update(id, requestDTO);
        redirectAttributes.addFlashAttribute("successMessage", "Supplier updated successfully");
        return "redirect:/supplier/list";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        supplierService.delete(id);
        redirectAttributes.addFlashAttribute("successMessage", "Supplier deleted successfully");
        return "redirect:/supplier/list";
    }
}
