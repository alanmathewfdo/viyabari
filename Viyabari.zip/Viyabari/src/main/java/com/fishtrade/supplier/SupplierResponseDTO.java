package com.fishtrade.supplier;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
public class SupplierResponseDTO {
    private Long supplierId;
    private String name;
    private String contactNumber;
    private String email;
    private String address;
    private SupplierType supplierType;
    private boolean isActive;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
