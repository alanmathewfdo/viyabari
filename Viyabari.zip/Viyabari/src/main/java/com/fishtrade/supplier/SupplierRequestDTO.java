package com.fishtrade.supplier;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SupplierRequestDTO {

    @NotBlank(message = "Supplier name is required")
    @Size(max = 100, message = "Name must be under 100 characters")
    private String name;

    @Size(max = 20, message = "Contact number must be under 20 characters")
    private String contactNumber;

    @Email(message = "Invalid email format")
    @Size(max = 100, message = "Email must be under 100 characters")
    private String email;

    private String address;

    @NotNull(message = "Supplier type is required")
    private SupplierType supplierType;

    private boolean isActive = true;
}
