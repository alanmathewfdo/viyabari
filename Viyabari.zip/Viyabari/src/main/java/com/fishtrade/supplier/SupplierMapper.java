package com.fishtrade.supplier;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

import java.util.List;

@Mapper(componentModel = "spring")
public interface SupplierMapper {

    SupplierResponseDTO toResponseDTO(Supplier supplier);

    Supplier toEntity(SupplierRequestDTO requestDTO);

    List<SupplierResponseDTO> toResponseDTOList(List<Supplier> suppliers);

    void updateEntityFromDTO(SupplierRequestDTO requestDTO, @MappingTarget Supplier supplier);
}
