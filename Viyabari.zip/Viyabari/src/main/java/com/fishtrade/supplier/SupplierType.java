package com.fishtrade.supplier;

public enum SupplierType {
    BOAT_OWNER, AUCTION, TRADER
}
