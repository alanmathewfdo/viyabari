package com.fishtrade.quality;

import com.fishtrade.purchase.PurchaseMaster;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "quality_inspections")
@Getter
@Setter
@NoArgsConstructor
public class QualityInspection {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long inspectionId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "purchase_id", nullable = false)
    private PurchaseMaster purchase;

    private String inspectorName;

    @CreationTimestamp
    private LocalDateTime inspectionDate;

    private String overallGrade;
    private String comments;
    private boolean isPassed = true;
}
