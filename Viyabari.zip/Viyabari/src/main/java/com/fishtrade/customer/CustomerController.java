package com.fishtrade.customer;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/customer")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerRepository customerRepository;

    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("customers", customerRepository.findAll());
        return "customer/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("customerRequestDTO", new CustomerRequestDTO());
        return "customer/add";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute CustomerRequestDTO dto, 
                       BindingResult bindingResult, 
                       RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) return "customer/add";
        
        Customer customer = new Customer();
        customer.setName(dto.getName());
        customer.setContactPerson(dto.getContactPerson());
        customer.setContactNumber(dto.getContactNumber());
        customer.setEmail(dto.getEmail());
        customer.setAddress(dto.getAddress());
        
        customerRepository.save(customer);
        redirectAttributes.addFlashAttribute("successMessage", "Customer added successfully");
        return "redirect:/customer/list";
    }
}
