package com.fishtrade.customer;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CustomerRequestDTO {
    @NotBlank(message = "Customer name is required")
    private String name;
    private String contactPerson;
    private String contactNumber;
    @Email(message = "Invalid email format")
    private String email;
    private String address;
}
