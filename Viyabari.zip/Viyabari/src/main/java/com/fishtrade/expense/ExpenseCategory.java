package com.fishtrade.expense;

public enum ExpenseCategory {
    FUEL, ICE, TRANSPORTATION, PACKAGING, LABOR, COLD_STORAGE
}
