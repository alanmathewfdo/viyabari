package com.fishtrade.fish;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FishRequestDTO {

    @NotBlank(message = "Fish name is required")
    @Size(max = 100, message = "Name must be under 100 characters")
    private String name;

    @Size(max = 100, message = "Scientific name must be under 100 characters")
    private String scientificName;

    @NotNull(message = "Category is required")
    private Long categoryId;

    private boolean isActive = true;
}
