package com.fishtrade.fish;

import com.fishtrade.shared.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FishService {

    private final FishRepository fishRepository;
    private final FishCategoryRepository categoryRepository;
    private final FishMapper fishMapper;

    // Category Methods
    @Transactional(readOnly = true)
    public List<FishCategoryResponseDTO> getAllCategories() {
        return fishMapper.toCategoryResponseList(categoryRepository.findAll());
    }

    @Transactional
    public FishCategoryResponseDTO saveCategory(FishCategoryRequestDTO dto) {
        FishCategory category = fishMapper.toCategoryEntity(dto);
        return fishMapper.toCategoryResponse(categoryRepository.save(category));
    }

    // Fish Methods
    @Transactional(readOnly = true)
    public List<FishResponseDTO> getAllFishes() {
        return fishMapper.toFishResponseList(fishRepository.findAll());
    }

    @Transactional
    public FishResponseDTO saveFish(FishRequestDTO dto) {
        FishCategory category = categoryRepository.findById(dto.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));
        
        Fish fish = fishMapper.toFishEntity(dto);
        fish.setCategory(category);
        return fishMapper.toFishResponse(fishRepository.save(fish));
    }

    @Transactional(readOnly = true)
    public FishResponseDTO getFishById(Long id) {
        Fish fish = fishRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Fish not found"));
        return fishMapper.toFishResponse(fish);
    }
}
