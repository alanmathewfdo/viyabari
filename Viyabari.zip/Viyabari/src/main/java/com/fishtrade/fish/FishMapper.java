package com.fishtrade.fish;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.List;

@Mapper(componentModel = "spring")
public interface FishMapper {

    FishCategoryResponseDTO toCategoryResponse(FishCategory category);
    FishCategory toCategoryEntity(FishCategoryRequestDTO dto);
    List<FishCategoryResponseDTO> toCategoryResponseList(List<FishCategory> categories);
    void updateCategoryFromDTO(FishCategoryRequestDTO dto, @MappingTarget FishCategory category);

    @Mapping(source = "category.categoryId", target = "categoryId")
    @Mapping(source = "category.name", target = "categoryName")
    FishResponseDTO toFishResponse(Fish fish);

    @Mapping(target = "category", ignore = true)
    Fish toFishEntity(FishRequestDTO dto);

    List<FishResponseDTO> toFishResponseList(List<Fish> fishes);

    @Mapping(target = "category", ignore = true)
    void updateFishFromDTO(FishRequestDTO dto, @MappingTarget Fish fish);
}
