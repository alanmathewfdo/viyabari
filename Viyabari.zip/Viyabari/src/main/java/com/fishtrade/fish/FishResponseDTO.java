package com.fishtrade.fish;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FishResponseDTO {
    private Long fishId;
    private String name;
    private String scientificName;
    private Long categoryId;
    private String categoryName;
    private boolean isActive;
}
