package com.fishtrade.fish;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FishCategoryResponseDTO {
    private Long categoryId;
    private String name;
    private String description;
}
