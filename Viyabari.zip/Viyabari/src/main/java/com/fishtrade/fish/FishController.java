package com.fishtrade.fish;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/fish")
@RequiredArgsConstructor
public class FishController {

    private final FishService fishService;

    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("fishes", fishService.getAllFishes());
        return "fish/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("fishRequestDTO", new FishRequestDTO());
        model.addAttribute("categories", fishService.getAllCategories());
        return "fish/add";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute FishRequestDTO dto, 
                       BindingResult bindingResult, 
                       Model model,
                       RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("categories", fishService.getAllCategories());
            return "fish/add";
        }
        fishService.saveFish(dto);
        redirectAttributes.addFlashAttribute("successMessage", "Fish added successfully");
        return "redirect:/fish/list";
    }

    @GetMapping("/category/list")
    public String categoryList(Model model) {
        model.addAttribute("categories", fishService.getAllCategories());
        model.addAttribute("categoryRequestDTO", new FishCategoryRequestDTO());
        return "fish/category-list";
    }

    @PostMapping("/category/save")
    public String saveCategory(@Valid @ModelAttribute FishCategoryRequestDTO dto, 
                               BindingResult bindingResult, 
                               RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "fish/category-list";
        }
        fishService.saveCategory(dto);
        redirectAttributes.addFlashAttribute("successMessage", "Category added successfully");
        return "redirect:/fish/category/list";
    }
}
