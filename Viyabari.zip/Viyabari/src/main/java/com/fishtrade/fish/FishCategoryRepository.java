package com.fishtrade.fish;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FishCategoryRepository extends JpaRepository<FishCategory, Long> {
}
