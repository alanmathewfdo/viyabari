package com.fishtrade.fish;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FishCategoryRequestDTO {

    @NotBlank(message = "Category name is required")
    @Size(max = 100, message = "Name must be under 100 characters")
    private String name;

    private String description;
}
