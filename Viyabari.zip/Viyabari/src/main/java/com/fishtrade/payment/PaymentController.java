package com.fishtrade.payment;

import com.fishtrade.customer.CustomerRepository;
import com.fishtrade.supplier.SupplierRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/payment")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;
    private final SupplierRepository supplierRepository;
    private final CustomerRepository customerRepository;

    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("payments", paymentService.getAll());
        return "payment/list";
    }

    @GetMapping("/add")
    public String showAddForm(@RequestParam PaymentType type, Model model) {
        PaymentRequestDTO dto = new PaymentRequestDTO();
        dto.setPaymentType(type);
        
        model.addAttribute("paymentRequestDTO", dto);
        model.addAttribute("suppliers", supplierRepository.findAll());
        model.addAttribute("customers", customerRepository.findAll());
        return "payment/add";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute PaymentRequestDTO dto, 
                       BindingResult bindingResult, 
                       Model model,
                       RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("suppliers", supplierRepository.findAll());
            model.addAttribute("customers", customerRepository.findAll());
            return "payment/add";
        }
        paymentService.save(dto);
        redirectAttributes.addFlashAttribute("successMessage", "Payment recorded successfully");
        return "redirect:/payment/list";
    }
}
