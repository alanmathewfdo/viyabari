package com.fishtrade.payment;

public enum PaymentType {
    TO_SUPPLIER, FROM_CUSTOMER
}
