package com.fishtrade.payment;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
public class PaymentResponseDTO {
    private Long paymentId;
    private LocalDate paymentDate;
    private PaymentType paymentType;
    private Long supplierId;
    private String supplierName;
    private Long customerId;
    private String customerName;
    private BigDecimal amount;
    private String paymentMethod;
    private String referenceNumber;
    private String notes;
    private LocalDateTime createdAt;
}
