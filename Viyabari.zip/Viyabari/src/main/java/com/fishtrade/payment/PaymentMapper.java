package com.fishtrade.payment;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface PaymentMapper {

    @Mapping(source = "supplier.supplierId", target = "supplierId")
    @Mapping(source = "supplier.name", target = "supplierName")
    @Mapping(source = "customer.customerId", target = "customerId")
    @Mapping(source = "customer.name", target = "customerName")
    PaymentResponseDTO toResponseDTO(Payment payment);

    @Mapping(target = "supplier", ignore = true)
    @Mapping(target = "customer", ignore = true)
    Payment toEntity(PaymentRequestDTO dto);

    List<PaymentResponseDTO> toResponseDTOList(List<Payment> payments);
}
