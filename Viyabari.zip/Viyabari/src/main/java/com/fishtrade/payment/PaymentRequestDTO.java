package com.fishtrade.payment;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
public class PaymentRequestDTO {

    @NotNull(message = "Payment date is required")
    private LocalDate paymentDate = LocalDate.now();

    @NotNull(message = "Payment type is required")
    private PaymentType paymentType;

    private Long supplierId;
    private Long customerId;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be greater than zero")
    private BigDecimal amount;

    private String paymentMethod;
    private String referenceNumber;
    private String notes;
}
