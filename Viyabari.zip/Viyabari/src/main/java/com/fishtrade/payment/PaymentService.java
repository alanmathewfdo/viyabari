package com.fishtrade.payment;

import com.fishtrade.customer.CustomerRepository;
import com.fishtrade.shared.exception.ResourceNotFoundException;
import com.fishtrade.supplier.SupplierRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final SupplierRepository supplierRepository;
    private final CustomerRepository customerRepository;
    private final PaymentMapper paymentMapper;

    @Transactional(readOnly = true)
    public List<PaymentResponseDTO> getAll() {
        return paymentMapper.toResponseDTOList(paymentRepository.findAll());
    }

    @Transactional
    public PaymentResponseDTO save(PaymentRequestDTO dto) {
        Payment payment = paymentMapper.toEntity(dto);

        if (dto.getPaymentType() == PaymentType.TO_SUPPLIER) {
            if (dto.getSupplierId() == null) throw new IllegalArgumentException("Supplier ID is required for outgoing payment");
            payment.setSupplier(supplierRepository.findById(dto.getSupplierId())
                    .orElseThrow(() -> new ResourceNotFoundException("Supplier not found")));
        } else {
            if (dto.getCustomerId() == null) throw new IllegalArgumentException("Customer ID is required for incoming payment");
            payment.setCustomer(customerRepository.findById(dto.getCustomerId())
                    .orElseThrow(() -> new ResourceNotFoundException("Customer not found")));
        }

        return paymentMapper.toResponseDTO(paymentRepository.save(payment));
    }
}
