CREATE TABLE export_orders (
    export_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    export_order_number VARCHAR(20) NOT NULL UNIQUE, -- EXP-YYYY-NNNN
    sale_id BIGINT NOT NULL,
    shipment_date DATE,
    container_number VARCHAR(50),
    destination_country VARCHAR(100),
    port_of_loading VARCHAR(100),
    port_of_discharge VARCHAR(100),
    status VARCHAR(20), -- PENDING, SHIPPED, DELIVERED
    FOREIGN KEY (sale_id) REFERENCES sales_master(sale_id)
);
