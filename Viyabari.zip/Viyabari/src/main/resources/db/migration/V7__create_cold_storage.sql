CREATE TABLE cold_storage_rooms (
    room_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    room_name VARCHAR(50) NOT NULL UNIQUE,
    capacity_kg DECIMAL(12, 2) NOT NULL,
    current_load DECIMAL(12, 2) DEFAULT 0.00,
    temperature_celsius DECIMAL(5, 2),
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE storage_transactions (
    transaction_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    room_id BIGINT NOT NULL,
    fish_id BIGINT NOT NULL,
    transaction_type VARCHAR(10) NOT NULL, -- IN, OUT
    quantity_kg DECIMAL(10, 2) NOT NULL,
    transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES cold_storage_rooms(room_id),
    FOREIGN KEY (fish_id) REFERENCES fishes(fish_id)
);
