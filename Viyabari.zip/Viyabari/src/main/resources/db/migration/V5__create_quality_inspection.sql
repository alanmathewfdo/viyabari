CREATE TABLE quality_inspections (
    inspection_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    purchase_id BIGINT NOT NULL,
    inspector_name VARCHAR(100),
    inspection_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    overall_grade VARCHAR(5),
    comments TEXT,
    is_passed BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (purchase_id) REFERENCES purchase_master(purchase_id)
);
