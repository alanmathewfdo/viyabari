CREATE TABLE sales_master (
    sale_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(20) NOT NULL UNIQUE, -- INV-YYYY-NNNN
    customer_id BIGINT NOT NULL,
    sale_date DATE NOT NULL,
    sale_type VARCHAR(20) NOT NULL, -- LOCAL, EXPORT
    total_amount DECIMAL(15, 2) DEFAULT 0.00,
    status VARCHAR(20) NOT NULL, -- DRAFT, COMPLETED, CANCELLED
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE sales_items (
    sale_item_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sale_id BIGINT NOT NULL,
    fish_id BIGINT NOT NULL,
    quantity_kg DECIMAL(10, 2) NOT NULL,
    rate_per_kg DECIMAL(10, 2) NOT NULL,
    total_amount DECIMAL(15, 2) NOT NULL,
    FOREIGN KEY (sale_id) REFERENCES sales_master(sale_id),
    FOREIGN KEY (fish_id) REFERENCES fishes(fish_id)
);
