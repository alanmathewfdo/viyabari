CREATE TABLE payments (
    payment_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    payment_date DATE NOT NULL,
    payment_type VARCHAR(20) NOT NULL, -- TO_SUPPLIER, FROM_CUSTOMER
    supplier_id BIGINT,
    customer_id BIGINT,
    amount DECIMAL(15, 2) NOT NULL,
    payment_method VARCHAR(50), -- CASH, BANK_TRANSFER, CHEQUE
    reference_number VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);
