CREATE TABLE purchase_master (
    purchase_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    purchase_number VARCHAR(20) NOT NULL UNIQUE, -- PUR-YYYY-NNNN
    supplier_id BIGINT NOT NULL,
    boat_id BIGINT,
    purchase_date DATE NOT NULL,
    total_amount DECIMAL(15, 2) DEFAULT 0.00,
    status VARCHAR(20) NOT NULL, -- DRAFT, CONFIRMED, CANCELLED
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (boat_id) REFERENCES boats(boat_id)
);

CREATE TABLE purchase_items (
    purchase_item_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    purchase_id BIGINT NOT NULL,
    fish_id BIGINT NOT NULL,
    quantity_kg DECIMAL(10, 2) NOT NULL,
    rate_per_kg DECIMAL(10, 2) NOT NULL,
    total_amount DECIMAL(15, 2) NOT NULL,
    grade VARCHAR(5), -- A, B, C
    FOREIGN KEY (purchase_id) REFERENCES purchase_master(purchase_id),
    FOREIGN KEY (fish_id) REFERENCES fishes(fish_id)
);
