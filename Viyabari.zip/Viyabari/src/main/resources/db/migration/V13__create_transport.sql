CREATE TABLE vehicles (
    vehicle_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    vehicle_number VARCHAR(20) NOT NULL UNIQUE,
    vehicle_type VARCHAR(50),
    owner_name VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE deliveries (
    delivery_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sale_id BIGINT NOT NULL,
    vehicle_id BIGINT NOT NULL,
    driver_name VARCHAR(100),
    delivery_date DATETIME,
    status VARCHAR(20), -- IN_TRANSIT, DELIVERED
    FOREIGN KEY (sale_id) REFERENCES sales_master(sale_id),
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id)
);
