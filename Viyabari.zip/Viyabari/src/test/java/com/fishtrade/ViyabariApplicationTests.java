package com.fishtrade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViyabariApplicationTests {

    @Test
    void contextLoads() {
    }

}
