package org.example.viyabari;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViyabariApplicationTests {

    @Test
    void contextLoads() {
    }

}
